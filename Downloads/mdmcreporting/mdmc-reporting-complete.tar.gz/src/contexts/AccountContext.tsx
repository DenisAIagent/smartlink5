// src/contexts/AccountContext.tsx
import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { GoogleAdsAccount } from '@/types';
import { apiService } from '@/services/api';
import { useAuth } from './AuthContext';

interface AccountContextType {
  availableAccounts: GoogleAdsAccount[];
  activeAccount: GoogleAdsAccount | null;
  isLoading: boolean;
  error: string | null;
  switchAccount: (account: GoogleAdsAccount) => void;
  refreshAccounts: () => Promise<void>;
}

const AccountContext = createContext<AccountContextType | undefined>(undefined);

interface AccountProviderProps {
  children: ReactNode;
}

export function AccountProvider({ children }: AccountProviderProps) {
  const [availableAccounts, setAvailableAccounts] = useState<GoogleAdsAccount[]>([]);
  const [activeAccount, setActiveAccount] = useState<GoogleAdsAccount | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    if (isAuthenticated && user) {
      loadAvailableAccounts();
    } else {
      // Clear accounts when user logs out
      setAvailableAccounts([]);
      setActiveAccount(null);
    }
  }, [isAuthenticated, user]);

  const loadAvailableAccounts = async () => {
    setIsLoading(true);
    setError(null);

    try {
      if (process.env.NODE_ENV === 'development') {
        // Mock data for development
        const mockAccounts: GoogleAdsAccount[] = [
          {
            id: '1',
            customerId: '123-456-7890',
            name: 'Client A - E-commerce',
            currency: 'EUR',
            status: 'active',
            assignedUsers: ['2', '3'],
            totalBudget: 15420,
            spent: 12350,
            conversions: 247,
            lastSync: new Date('2024-01-20T10:30:00')
          },
          {
            id: '2',
            customerId: '098-765-4321',
            name: 'Client B - SaaS',
            currency: 'USD',
            status: 'active',
            assignedUsers: ['2'],
            totalBudget: 25000,
            spent: 18750,
            conversions: 189,
            lastSync: new Date('2024-01-20T09:15:00')
          },
          {
            id: '3',
            customerId: '555-123-9999',
            name: 'Client C - Retail',
            currency: 'EUR',
            status: 'active',
            assignedUsers: [],
            totalBudget: 8500,
            spent: 7200,
            conversions: 156,
            lastSync: new Date('2024-01-19T16:45:00')
          }
        ];

        // Filter accounts based on user permissions
        let filteredAccounts = mockAccounts;
        if (user?.role !== 'admin') {
          filteredAccounts = mockAccounts.filter(account => 
            user?.assignedAccounts.includes(account.customerId)
          );
        }

        setAvailableAccounts(filteredAccounts);
        
        // Auto-select first account if none selected
        if (!activeAccount && filteredAccounts.length > 0) {
          const savedAccountId = localStorage.getItem('mdmc_active_account');
          const savedAccount = filteredAccounts.find(acc => acc.id === savedAccountId);
          setActiveAccount(savedAccount || filteredAccounts[0]);
        }
      } else {
        // Production API call
        const response = await apiService.getAccessibleAccounts();
        
        if (response.success && response.data) {
          const accounts = response.data.map((acc: any) => ({
            ...acc,
            lastSync: new Date(acc.lastSync)
          }));
          
          setAvailableAccounts(accounts);
          
          // Auto-select first account if none selected
          if (!activeAccount && accounts.length > 0) {
            const savedAccountId = localStorage.getItem('mdmc_active_account');
            const savedAccount = accounts.find((acc: GoogleAdsAccount) => acc.id === savedAccountId);
            setActiveAccount(savedAccount || accounts[0]);
          }
        } else {
          throw new Error(response.error || 'Failed to load accounts');
        }
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load accounts';
      setError(errorMessage);
      console.error('Failed to load Google Ads accounts:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const switchAccount = (account: GoogleAdsAccount) => {
    setActiveAccount(account);
    localStorage.setItem('mdmc_active_account', account.id);
    
    // Optionally notify other parts of the app about account switch
    window.dispatchEvent(new CustomEvent('accountSwitched', { 
      detail: { account } 
    }));
  };

  const refreshAccounts = async () => {
    await loadAvailableAccounts();
  };

  const value: AccountContextType = {
    availableAccounts,
    activeAccount,
    isLoading,
    error,
    switchAccount,
    refreshAccounts,
  };

  return (
    <AccountContext.Provider value={value}>
      {children}
    </AccountContext.Provider>
  );
}

export function useAccount(): AccountContextType {
  const context = useContext(AccountContext);
  if (context === undefined) {
    throw new Error('useAccount must be used within an AccountProvider');
  }
  return context;
}