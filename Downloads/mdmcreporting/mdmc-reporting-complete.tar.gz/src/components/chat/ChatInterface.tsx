import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send, Bot, User, Loader2, RefreshCw } from 'lucide-react';
import MessageBubble from './MessageBubble';
import { useAccount } from '@/contexts/AccountContext';
import { useWebSocket } from '@/services/websocket';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  isLoading?: boolean;
  data?: any;
}

export default function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { activeAccount } = useAccount();
  const { sendMessage, connect, disconnect } = useWebSocket();

  useEffect(() => {
    // Initialize chat with welcome message
    const welcomeMessage: Message = {
      id: '1',
      type: 'assistant',
      content: `Bonjour ! 👋 Je suis votre assistant IA pour analyser vos campagnes Google Ads. 

Je peux vous aider à :
• Analyser les performances de vos campagnes
• Comparer les métriques entre différentes périodes
• Identifier les opportunités d'optimisation
• Créer des rapports personnalisés
• Configurer des alertes automatiques

${activeAccount ? `Compte actif : ${activeAccount.name} (${activeAccount.customerId})` : 'Sélectionnez d\'abord un compte Google Ads pour commencer.'}

Comment puis-je vous aider aujourd'hui ?`,
      timestamp: new Date()
    };
    setMessages([welcomeMessage]);

    // Connect to WebSocket
    connect();
    setIsConnected(true);

    return () => {
      disconnect();
      setIsConnected(false);
    };
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    if (!activeAccount) {
      const errorMessage: Message = {
        id: Date.now().toString(),
        type: 'assistant',
        content: '⚠️ Veuillez d\'abord sélectionner un compte Google Ads dans le header pour que je puisse analyser vos données.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    const loadingMessage: Message = {
      id: (Date.now() + 1).toString(),
      type: 'assistant',
      content: 'Analyse en cours...',
      timestamp: new Date(),
      isLoading: true
    };

    setMessages(prev => [...prev, userMessage, loadingMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      // Mock AI response - replace with actual Claude API integration
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const response = await generateMockResponse(inputValue, activeAccount);
      
      setMessages(prev => 
        prev.map(msg => 
          msg.id === loadingMessage.id 
            ? { ...msg, content: response.content, isLoading: false, data: response.data }
            : msg
        )
      );
    } catch (error) {
      setMessages(prev => 
        prev.map(msg => 
          msg.id === loadingMessage.id 
            ? { 
                ...msg, 
                content: '❌ Désolé, une erreur s\'est produite lors de l\'analyse. Veuillez réessayer.', 
                isLoading: false 
              }
            : msg
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  const generateMockResponse = async (query: string, account: any) => {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('performance') || lowerQuery.includes('campagne')) {
      return {
        content: `📊 **Analyse des performances pour ${account.name}**

Voici un aperçu de vos campagnes actives :

🎯 **Campagnes les plus performantes :**
• Black Friday Sale - ROAS: 4.2x (€2,450 dépensés, 89 conversions)
• Retargeting Premium - ROAS: 3.8x (€1,890 dépensés, 67 conversions)
• Search Brand - ROAS: 5.1x (€1,230 dépensés, 45 conversions)

📈 **Tendances cette semaine :**
• +12% d'augmentation des conversions
• -3% de diminution du CPC moyen
• +18% d'amélioration du taux de conversion

💡 **Recommandations :**
1. Augmenter le budget de "Search Brand" (meilleur ROAS)
2. Optimiser les audiences de "Retargeting Premium"
3. Tester de nouveaux mots-clés pour "Black Friday Sale"

Souhaitez-vous que j'approfondisse l'analyse d'une campagne spécifique ?`,
        data: {
          campaigns: [
            { name: 'Black Friday Sale', roas: 4.2, spend: 2450, conversions: 89 },
            { name: 'Retargeting Premium', roas: 3.8, spend: 1890, conversions: 67 },
            { name: 'Search Brand', roas: 5.1, spend: 1230, conversions: 45 }
          ]
        }
      };
    }
    
    if (lowerQuery.includes('budget') || lowerQuery.includes('dépense')) {
      return {
        content: `💰 **Analyse du budget pour ${account.name}**

📊 **Résumé budgétaire :**
• Budget total : €${account.totalBudget.toLocaleString()}
• Dépensé ce mois : €${account.spent.toLocaleString()}
• Reste disponible : €${(account.totalBudget - account.spent).toLocaleString()}
• Utilisation : ${Math.round((account.spent / account.totalBudget) * 100)}%

⚠️ **Alertes budget :**
• 2 campagnes approchent de leur limite (>80%)
• Budget quotidien de "Display Network" épuisé à 14h30

📈 **Optimisations suggérées :**
1. Réallouer €500 de "Display" vers "Search Brand"
2. Augmenter le budget de "Retargeting" de 20%
3. Mettre en pause les campagnes peu performantes

Voulez-vous que je configure des alertes automatiques pour vos budgets ?`
      };
    }

    if (lowerQuery.includes('alerte') || lowerQuery.includes('notification')) {
      return {
        content: `🔔 **Configuration des alertes pour ${account.name}**

✅ **Alertes actuellement actives :**
• Budget dépassé à 80% - Email + Dashboard
• ROAS en dessous de 2.0x - Email uniquement
• Campagne en pause automatique - Slack + Email

🆕 **Nouvelles alertes suggérées :**
• CPC augmente de plus de 20% - Dashboard
• Conversions diminuent de plus de 15% - Email
• Impression share en dessous de 50% - Dashboard

⚙️ **Options de notification :**
• 📧 Email (instantané ou résumé quotidien)
• 💬 Slack (canal #ads-alerts)
• 📱 Dashboard (notifications en temps réel)

Quelle alerte souhaitez-vous configurer ? Dites-moi simplement vos critères !`
      };
    }

    // Default response
    return {
      content: `Je comprends votre question : "${query}"

Pour ${account.name}, je peux analyser :
• 📊 Performances des campagnes et métriques
• 💰 Gestion des budgets et optimisations
• 🎯 Ciblage et audiences
• 📈 Tendances et comparaisons temporelles
• ⚠️ Alertes et notifications automatiques

Pouvez-vous préciser ce que vous aimeriez analyser ? Par exemple :
- "Montre-moi les performances de mes campagnes cette semaine"
- "Quelles campagnes ont le meilleur ROAS ?"
- "Configure une alerte si le budget dépasse 80%"
- "Compare les performances de novembre vs octobre"`
    };
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const clearChat = () => {
    setMessages([{
      id: Date.now().toString(),
      type: 'assistant',
      content: 'Chat effacé. Comment puis-je vous aider ?',
      timestamp: new Date()
    }]);
  };

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader className="bg-[#E53E3E] text-white rounded-t-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
              <Bot className="h-6 w-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg font-semibold">Assistant IA MDMC</CardTitle>
              <p className="text-sm text-red-100">
                Analyse conversationnelle de vos campagnes Google Ads
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant={isConnected ? "secondary" : "destructive"} className="bg-white bg-opacity-20">
              {isConnected ? '🟢 En ligne' : '🔴 Hors ligne'}
            </Badge>
            <Button variant="ghost" size="sm" onClick={clearChat} className="text-white hover:bg-white hover:bg-opacity-20">
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <MessageBubble key={message.id} message={message} />
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        <div className="border-t border-gray-200 p-4">
          <div className="flex items-center space-x-2">
            <div className="flex-1 relative">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={
                  activeAccount 
                    ? "Posez votre question sur les campagnes..." 
                    : "Sélectionnez d'abord un compte Google Ads..."
                }
                disabled={isLoading || !activeAccount}
                className="pr-12"
              />
              {isLoading && (
                <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 animate-spin text-gray-400" />
              )}
            </div>
            <Button
              onClick={handleSendMessage}
              disabled={isLoading || !inputValue.trim() || !activeAccount}
              className="bg-[#E53E3E] hover:bg-[#C53030]"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          
          {activeAccount && (
            <div className="mt-2 text-xs text-gray-500">
              💡 Exemples : "Performance des campagnes", "Budget restant", "Configurer une alerte"
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}