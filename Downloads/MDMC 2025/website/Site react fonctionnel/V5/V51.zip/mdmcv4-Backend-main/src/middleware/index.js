/**
 * Index des middlewares pour MDMC Music Ads v4
 */

const authJwt = require('./auth');

module.exports = {
  authJwt
};
